import '../model/profile_model.dart';

class ProfileViewModel {
  Profile profile = Profile(
    name: "Portia",
    surname: "Sefatsa",
    phone: "0608183468",
    email: "portiasefatsa@gmail.com",
    role: "Software Developer",
    language: "C# Dart",
  );

  void updateProfile(Profile updatedProfile) {
    profile = updatedProfile;
  }
}
